package ActividadPerlas;

public class Perla {
	private final String color;

	public Perla(String color) {
		this.color = color;
	}

	public String getColor() {
		return color;
	}
}

